import React from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import * as Animatable from 'react-native-animatable';
import { useNavigation } from "@react-navigation/native";

export default function SignUp() {
    const navigation = useNavigation();
    const handleGoBack = () => {
        navigation.goBack();
    }

    return (
        <View style={styles.container}>
            <Animatable.View animation='fadeInLeft' delay={500} style={styles.containerHeader}>
                <Text style={styles.message}>Voçê é novo por aqui? Faça seu cadastro.</Text>
            </Animatable.View>

            <Animatable.View animation='fadeInUp' style={styles.containerForm}>
                <Text style={styles.title}>Nome de usuário</Text>
                <TextInput
                    placeholder="Cadastre seu nome."
                    style={styles.input} />


                <Text style={styles.title}>E-mail</Text>
                <TextInput
                    placeholder="Cadastre seu e-mail."
                    style={styles.input} />

                <Text style={styles.title}>Senha</Text>
                <TextInput
                    placeholder="Crie sua senha."
                    style={styles.input}
                />

                <TouchableOpacity style={styles.button} >
                    <Text style={styles.buttonText}>Cadastrar.</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.button} onPress={handleGoBack}>
                    <Text style={styles.buttonText}>Voltar</Text>
                </TouchableOpacity>


                <TouchableOpacity style={styles.buttonRegister} onPress={() => navigation.navigate('Login')}>
                    <Text style={styles.registerText}>Já possui uma conta? Faça login.</Text>
                </TouchableOpacity>
            </Animatable.View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#38A69D',
    },
    containerHeader: {
        marginTop: '14%',
        marginLeft: '30%',
        marginBottom: '8%',
        paddingStart: '5%',
    },
    message: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#FFf',
        left: '-20%',
    },
    containerForm: {
        backgroundColor: '#FFf',
        flex: 1,
        borderTopLeftRadius: 25,
        borderTopRightRadius: 25,
        paddingStart: '5%',
        paddingEnd: '5%',
    },
    title: {
        fontSize: 30,
        marginTop: 28,
    },
    input: {
        borderBottomWidth: 1,
        height: 40,
        marginBottom: 12,
        fontSize: 16,
    },
    button: {
        backgroundColor: '#38A69D',
        width: '100%',
        borderRadius: 4,
        paddingVertical: 8,
        marginTop: 14,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonText: {
        color: '#FFf',
        fontSize: 18,
        fontWeight: 'bold',
    },
    buttonRegister: {
        marginTop: 14,
        alignSelf: 'center',
    },
    registerText: {
        fontSize: 20,
        color: '#A1a1a1',
    },
})
