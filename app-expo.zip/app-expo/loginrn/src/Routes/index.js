import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { NavigationContainer } from "@react-navigation/native";
import Welcome from "../pages/Welcome";
import Cadastro from "../pages/Cadastro";
import Login from "../pages/Login";
import Home from "../pages/Home";
import { AppStack } from "./AppStack";
import {AuthStack} from './AuthStack';
import {useAuth} from '../contexts/Auth';



const Stack = createNativeStackNavigator();

export default function ROUTES() {
    const {authData, isLoading} = useAuth();

    if (isLoading) {
      console.log({isLoading});
      return (
        <View style={{justifyContent: 'center', alignItems: 'center', flex: 1}}>
          <Text>Carregando informações....</Text>
        </View>
      );
    }
    return (
        <NavigationContainer>
        {authData ? <AppStack /> : <AuthStack />}
      </NavigationContainer>,
        <Stack.Navigator>
            <Stack.Screen
                name="Welcome"
                component={Welcome}
                options={{ headerShown: false }}
            />

            <Stack.Screen
                name="Login"
                component={Login}
                options={{ headerShown: false }}
            />

            <Stack.Screen
                name="Cadastro"
                component={Cadastro}
                options={{ headerShown: false }}
            />

            <Stack.Screen
                name="Home"
                component={Home}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    )

}

